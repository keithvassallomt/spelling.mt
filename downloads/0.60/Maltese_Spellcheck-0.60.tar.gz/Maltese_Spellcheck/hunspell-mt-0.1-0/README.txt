mt_MT Hunspell Dictionary
Version 2019.10.17
https://spelling.mt

This dictionary was created from the Maltese word list for aspell,
originally created by the late Ramon Casha. It was repackaged to 
Hunspell by Keith Vassallo. 

The following dictionaries are available:

  mt_MT (Maltese)
 
Note that the affix file for this dictionary is only a placeholder.
Hence, certain suffixes will not work. For example:

inħobb -> recognised
inħobbu -> not recognised

An affix file may become available if the repackager figures out how
to do so, or if some kind soul who know what they're doing contributes 
it.